import{_ as e}from"./ZTfPlI5l.js";import{N as r,D as c}from"./Da2siIm2.js";const n={};function o(t,a){return c(),r("div",null,"Car")}const f=e(n,[["render",o]]);export{f as default};
